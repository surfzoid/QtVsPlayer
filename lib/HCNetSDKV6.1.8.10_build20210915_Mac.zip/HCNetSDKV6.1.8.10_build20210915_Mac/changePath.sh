#!/bin/bash
	install_name_tool -change /usr/local/lib/libsystemtrans11.dylib  @loader_path/libSystemTranform.dylib "libHCNetSDK.dylib"
	install_name_tool -change @loader_path/libPlayCtrl.dylib  @loader_path/libPlayCtrl.dylib "libHCNetSDK.dylib"
